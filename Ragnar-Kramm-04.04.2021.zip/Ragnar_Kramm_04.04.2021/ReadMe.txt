Ragnar Kramm Testülesande lahendus.

NB! Rakenduse käivitamiseks vajalik Java SE 11.

SpinTEK kaustas on .java failid kus asub programmi kood.
Lisaks on võimalik java faile ja koodi näha aadressiklt: https://github.com/RagnarKramm/SpinTEK_TestEX

JUHEND: Rakenduse käivitamiseks tuleb teha topeltklõps AccountantHelper.bat failile, mis käivitab SpinTEK.jar faili.

Kasutaja peab sisestama aasta arvu, sobivad väärtused 1000-9999, seejärel tuleb vajutada ENTER nuppu.

Rakendusega samasse kausta salvestatakse aastaarv.csv fail ja ka rakendusse trükitakse tabel formaadis KUU;PALGAPÄEV;MEELDETULETUSPÄEV.

Rakendusest väljumiseks vajutage ENTER nuppu klaviatuuril.
